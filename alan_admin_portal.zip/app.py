"""ALAN ADMIN PORTAL entry point: page config, CSS, sidebar, and screen router."""

import streamlit as st

from api import get_current_user
from state import go, init_state
from screens.main_screen import render_main_screen
from screens.viewer_screen import render_viewer_screen
from screens.editor_screen import render_editor_screen

# ---------------------------------------------------------------------------
# Page config & state
# ---------------------------------------------------------------------------
st.set_page_config(page_title="ALAN ADMIN PORTAL", layout="wide")
init_state()

# ---------------------------------------------------------------------------
# CSS  (strict White & Red theme, kept under 20 lines)
# ---------------------------------------------------------------------------
st.markdown("""
<style>
:root{--red:#C0392B;--red-light:#E74C3C;--grey:#F8F9FA;}
header[data-testid="stHeader"]{background:#fff;border-bottom:2px solid var(--red);}
[data-testid="stSidebar"]{background:#fff;border-right:2px solid var(--red);}
h1,h2,h3{color:var(--red)!important;}
div.stButton>button{background:var(--red);color:#fff;border:none;border-radius:4px;padding:.45rem 1.1rem;}
div.stButton>button:hover{background:var(--red-light);color:#fff;}
div[data-testid="stDialog"] button{background:var(--red);color:#fff;border:none;}
.active-banner{background:var(--grey);border-left:4px solid var(--red);padding:12px 18px;margin-bottom:10px;border-radius:4px;}
.active-banner h3{margin:0;font-size:1.05rem;}
.meta-card{background:var(--grey);padding:14px 18px;border-radius:6px;margin-bottom:6px;}
</style>
""", unsafe_allow_html=True)

# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------
ASSET_TYPES = ["usecase_schema", "model_schema", "experiment_schema", "code_schema"]

user = get_current_user()

with st.sidebar:
    st.markdown("### ALAN ADMIN PORTAL")
    st.divider()
    st.markdown("**Logged In User**")
    st.text(user["email"])
    st.text(f"Role: {user['role']}")
    st.divider()

    prev = st.session_state.asset_type
    asset = st.selectbox("Asset Type", ASSET_TYPES, index=ASSET_TYPES.index(prev))
    if asset != prev:
        st.session_state.asset_type = asset
        go("main", selected_version=None, editor_mode=None, editor_payload=None)
        st.rerun()

# ---------------------------------------------------------------------------
# Screen router
# ---------------------------------------------------------------------------
if st.session_state.screen == "main":
    render_main_screen()
elif st.session_state.screen == "viewer":
    render_viewer_screen()
elif st.session_state.screen == "editor":
    render_editor_screen()
