"""Viewer screen: read-only schema display with metadata and download."""

import copy
import json

import streamlit as st

from components.schema_form import render_schema_form
from state import _go, _versions


def render_viewer_screen():
    ver_id = st.session_state.selected_version
    record = None
    for v in _versions():
        if v["version"] == ver_id:
            record = v
            break
    if not record:
        st.error("Version not found.")
        if st.button("Back to Main"):
            _go("main")
            st.rerun()
        st.stop()

    if st.button("Back to Main"):
        _go("main")
        st.rerun()

    st.markdown(
        f"## Viewer  --  "
        f"{st.session_state.asset_type.replace('_', ' ').title()} / {record['version']}"
    )

    # Metadata card
    st.markdown(
        f'<div class="meta-card">'
        f'<b>Uploaded by:</b> {record["uploaded_by"]} &nbsp;|&nbsp; '
        f'<b>Last Updated:</b> {record["last_updated"]} &nbsp;|&nbsp; '
        f'<b>State:</b> {record["state"]}</div>',
        unsafe_allow_html=True,
    )

    # Form-like read-only view
    st.markdown("### Schema Payload")
    render_schema_form(record["payload"], editable=False, key_prefix="view")

    # Download
    st.download_button(
        "Download Schema (JSON)",
        data=json.dumps(
            {"version": record["version"], "payload": record["payload"]},
            indent=2,
        ),
        file_name=f"{st.session_state.asset_type}_{record['version']}.json",
        mime="application/json",
    )

    # State-based actions
    if record["state"] == "draft":
        if st.button("Edit Draft"):
            _go(
                "editor",
                editor_mode="edit",
                editor_payload=copy.deepcopy(record["payload"]),
                editor_source_version=record["version"],
            )
            st.rerun()
