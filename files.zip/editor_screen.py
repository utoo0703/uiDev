"""Editor screen: editable schema form with Save and Submit actions."""

import time

import streamlit as st

from components.schema_form import render_schema_form
from state import _active_version, _go, _next_version_tag, _versions


def render_editor_screen():
    mode = st.session_state.editor_mode        # "clone" or "edit"
    payload = st.session_state.editor_payload
    source_ver = st.session_state.editor_source_version

    if st.button("Cancel"):
        if mode == "clone":
            _go("main")
        else:
            _go("viewer", selected_version=source_ver)
        st.rerun()

    label = "Clone from Active" if mode == "clone" else f"Edit Draft {source_ver}"
    st.markdown(f"## Editor  --  {label}")

    # Editable form — collects edited values back
    edited_payload = render_schema_form(payload, editable=True, key_prefix="edit")

    st.divider()

    # ------------------------------------------------------------------
    # Submit dialog
    # ------------------------------------------------------------------
    @st.dialog("Confirm Submit")
    def _submit_dialog():
        st.write(
            "Promote this version to **active**? "
            "The current active version will be archived."
        )
        if st.button("Confirm Submit", key="submit_confirm"):
            versions = _versions()
            prev_active = _active_version()
            if mode == "clone":
                new_tag = _next_version_tag()
                new_rec = {
                    "version": new_tag,
                    "state": "active",
                    "is_active": True,
                    "uploaded_by": "admin@alan.io",
                    "last_updated": time.strftime("%Y-%m-%d"),
                    "rollback_id": (
                        prev_active["version"] if prev_active else None
                    ),
                    "payload": edited_payload,
                }
                versions.append(new_rec)
            else:
                # edit mode — promote existing draft
                for v in versions:
                    if v["version"] == source_ver:
                        v["payload"] = edited_payload
                        v["state"] = "active"
                        v["is_active"] = True
                        v["rollback_id"] = (
                            prev_active["version"] if prev_active else None
                        )
                        break
            # Ensure single active: archive any version that isn't the
            # newly promoted one
            newly_active_ver = (
                new_rec["version"] if mode == "clone" else source_ver
            )
            for v in versions:
                if v["is_active"] and v["version"] != newly_active_ver:
                    v["state"] = "archived"
                    v["is_active"] = False
            st.balloons()
            st.success("Version promoted to active.")
            time.sleep(1.5)
            _go("main", editor_mode=None, editor_payload=None)
            st.rerun()

    # ------------------------------------------------------------------
    # Action buttons
    # ------------------------------------------------------------------
    b1, b2 = st.columns(2)
    with b1:
        if st.button("Save", use_container_width=True):
            versions = _versions()
            if mode == "clone":
                new_tag = _next_version_tag()
                versions.append(
                    {
                        "version": new_tag,
                        "state": "draft",
                        "is_active": False,
                        "uploaded_by": "admin@alan.io",
                        "last_updated": time.strftime("%Y-%m-%d"),
                        "rollback_id": None,
                        "payload": edited_payload,
                    }
                )
                st.success(f"Saved as new draft {new_tag}.")
            else:
                for v in versions:
                    if v["version"] == source_ver:
                        v["payload"] = edited_payload
                        break
                st.success(f"Draft {source_ver} updated.")
            time.sleep(1.5)
            _go("main", editor_mode=None, editor_payload=None)
            st.rerun()
    with b2:
        if st.button("Submit", use_container_width=True):
            _submit_dialog()
