"""Main screen: active banner, clone, rollback, and version history table."""

import copy
import time

import pandas as pd
import streamlit as st

from state import _active_version, _go, _versions


def render_main_screen():
    st.markdown(
        f"## {st.session_state.asset_type.replace('_', ' ').title()}"
    )

    active = _active_version()

    # ------------------------------------------------------------------
    # Active version banner + Clone + Rollback
    # ------------------------------------------------------------------
    if active:
        st.markdown(
            f'<div class="active-banner"><h3>Active Version: {active["version"]}'
            f' &mdash; last updated {active["last_updated"]}</h3></div>',
            unsafe_allow_html=True,
        )

        # Rollback dialog (must be defined before the button that calls it)
        @st.dialog("Confirm Rollback")
        def _rollback_dialog():
            if not active.get("rollback_id"):
                st.warning("No previous active version to rollback to.")
                return
            st.write(
                f"Rollback active from **{active['version']}** to **{active['rollback_id']}**?"
            )
            if st.button("Confirm Rollback", key="rb_confirm"):
                target_id = active["rollback_id"]
                for v in _versions():
                    if v["version"] == target_id:
                        v["state"] = "active"
                        v["is_active"] = True
                        v["rollback_id"] = None
                    if v["version"] == active["version"]:
                        v["state"] = "archived"
                        v["is_active"] = False
                st.success("Rollback successful.")
                time.sleep(1.5)
                st.rerun()

        c1, c2, c3 = st.columns([1, 1, 4])
        with c1:
            if st.button("Clone Active Schema"):
                _go(
                    "editor",
                    editor_mode="clone",
                    editor_payload=copy.deepcopy(active["payload"]),
                    editor_source_version=active["version"],
                )
                st.rerun()
        with c2:
            if st.button("Rollback"):
                _rollback_dialog()

    # ------------------------------------------------------------------
    # Version History Table
    # ------------------------------------------------------------------
    st.markdown("### Version History")
    versions = _versions()
    display = []
    for v in versions:
        display.append(
            {
                "Version": v["version"],
                "State": v["state"],
                "Active": v["is_active"],
                "Uploaded By": v["uploaded_by"],
                "Last Updated": v["last_updated"],
            }
        )
    df = pd.DataFrame(display)
    event = st.dataframe(
        df,
        on_select="rerun",
        selection_mode="single-row",
        use_container_width=True,
        hide_index=True,
    )

    sel_rows = event.selection.rows if event.selection else []

    if sel_rows:
        chosen_idx = sel_rows[0]
        chosen = versions[chosen_idx]
        st.info(f"Selected: **{chosen['version']}** ({chosen['state']})")
        if st.button("View Schema"):
            _go("viewer", selected_version=chosen["version"])
            st.rerun()
