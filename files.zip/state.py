"""Session state initialization and shared helper functions."""

import streamlit as st

from mock_data import build_store


def init_state():
    """Set all session_state defaults. Called once from app.py."""
    if "store" not in st.session_state:
        st.session_state.store = build_store()
    if "screen" not in st.session_state:
        st.session_state.screen = "main"
    if "asset_type" not in st.session_state:
        st.session_state.asset_type = "usecase_schema"
    if "selected_version" not in st.session_state:
        st.session_state.selected_version = None
    if "editor_mode" not in st.session_state:
        st.session_state.editor_mode = None
    if "editor_payload" not in st.session_state:
        st.session_state.editor_payload = None
    if "editor_source_version" not in st.session_state:
        st.session_state.editor_source_version = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _versions(asset=None):
    """Return the version list for the given (or current) asset type."""
    return st.session_state.store[asset or st.session_state.asset_type]


def _active_version(asset=None):
    """Return the active version record, or None."""
    for v in _versions(asset):
        if v["is_active"]:
            return v
    return None


def _next_version_tag(asset=None):
    """Generate the next version string (e.g. 'v4') for the asset type."""
    nums = [int(v["version"].replace("v", "")) for v in _versions(asset)]
    return f"v{max(nums) + 1}"


def _go(screen, **kwargs):
    """Navigate to a screen, optionally setting extra session_state keys."""
    st.session_state.screen = screen
    for k, v in kwargs.items():
        st.session_state[k] = v
