"""Mock data factory for the ALAN ADMIN PORTAL skeleton."""

# ---------------------------------------------------------------------------
# MOCK DATA — Will be replaced by API calls to
# GET /api/v1/schema_versions/{asset_type}
# ---------------------------------------------------------------------------


def build_store():
    """Return a dict keyed by asset type, each holding a list of version records.

    Simplified to a single v1 (active) per asset type for testing.
    Payload structures intentionally exercise every renderer path:
    nested dicts, lists of dicts, lists of primitives, and scalars.
    """

    payloads = {
        "usecase_schema": {
            "name": "Fraud Detection",
            "domain": "finance",
            "features": ["txn_amount", "merchant_id", "ip_geo"],
            "config": {
                "threshold": 0.85,
                "ensemble": True,
                "fallback": "rule_engine",
            },
        },
        "model_schema": {
            "model_name": "XGBoost-v1",
            "framework": "xgboost",
            "hyperparams": {
                "n_estimators": 200,
                "max_depth": 6,
                "learning_rate": 0.1,
            },
            "metrics": {"auc": 0.91, "f1": 0.87},
        },
        "experiment_schema": {
            "experiment": "AB-Test-Checkout",
            "variant_count": 2,
            "variants": [
                {"id": "A", "weight": 0.5},
                {"id": "B", "weight": 0.5},
            ],
            "kpis": {"conversion": 0.032, "revenue_lift": 0.0},
        },
        "code_schema": {
            "module": "preprocessor",
            "language": "python",
            "entrypoint": "run()",
            "dependencies": ["pandas", "numpy"],
            "settings": {
                "timeout_s": 120,
                "retry": False,
            },
        },
    }

    store = {}
    for asset, payload in payloads.items():
        store[asset] = [
            {
                "version": "v1",
                "state": "active",
                "is_active": True,
                "uploaded_by": "admin@alan.io",
                "last_updated": "2025-06-10",
                "rollback_id": None,
                "payload": payload,
            }
        ]
    return store
