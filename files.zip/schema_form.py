"""Shared schema form renderer used by both Viewer and Editor screens."""

import streamlit as st
import pandas as pd


def render_schema_form(payload: dict, editable: bool = False, key_prefix: str = "form") -> dict:
    """Render a schema payload as a form and return the (possibly edited) result.

    Args:
        payload:    The schema dict to render.
        editable:   If True, widgets are interactive and edits are collected.
        key_prefix: Unique prefix for Streamlit widget keys to avoid collisions.

    Returns:
        The edited payload dict when editable=True, or the original payload when False.
    """
    result = {}

    with st.container(height=600):
        for top_key, val in payload.items():
            if isinstance(val, dict):
                result[top_key] = _render_dict(
                    top_key, val, editable, key_prefix
                )
            elif isinstance(val, list):
                if val and isinstance(val[0], dict):
                    result[top_key] = _render_list_of_dicts(
                        top_key, val, editable, key_prefix
                    )
                else:
                    result[top_key] = _render_list_of_primitives(
                        top_key, val, editable, key_prefix
                    )
            else:
                result[top_key] = _render_scalar(
                    top_key, val, editable, key_prefix
                )

    return result if editable else payload


# ---------------------------------------------------------------------------
# Private renderers
# ---------------------------------------------------------------------------

def _render_dict(key: str, val: dict, editable: bool, prefix: str) -> dict:
    """Render a dict as vertical key-value fields inside an expander."""
    collected = {}
    with st.expander(key, expanded=True):
        for k, v in val.items():
            widget_key = f"{prefix}_{key}_{k}"
            if isinstance(v, bool):
                collected[k] = st.checkbox(
                    k, value=v, disabled=not editable, key=widget_key
                )
            elif isinstance(v, int):
                collected[k] = st.number_input(
                    k, value=v, step=1, disabled=not editable, key=widget_key
                )
            elif isinstance(v, float):
                collected[k] = st.number_input(
                    k, value=v, disabled=not editable, key=widget_key
                )
            else:
                new_val = st.text_input(
                    k, value=str(v), disabled=not editable, key=widget_key
                )
                collected[k] = new_val
    return collected


def _render_list_of_dicts(key: str, val: list, editable: bool, prefix: str) -> list:
    """Render a list of dicts as a data_editor table inside an expander."""
    with st.expander(key, expanded=True):
        df = pd.DataFrame(val)
        edited_df = st.data_editor(
            df,
            disabled=not editable,
            num_rows="dynamic" if editable else "fixed",
            use_container_width=True,
            hide_index=True,
            key=f"{prefix}_{key}",
        )
    return edited_df.to_dict(orient="records")


def _render_list_of_primitives(key: str, val: list, editable: bool, prefix: str) -> list:
    """Render a list of primitives as a comma-separated text area inside an expander."""
    with st.expander(key, expanded=True):
        csv_str = ", ".join(str(x) for x in val)
        edited_str = st.text_area(
            key, value=csv_str, disabled=not editable, key=f"{prefix}_{key}"
        )

    if not editable:
        return val

    # Parse comma-separated string back into a typed list
    raw_items = [s.strip() for s in edited_str.split(",") if s.strip()]
    if not val:
        return raw_items

    # Attempt to preserve the original element type
    sample_type = type(val[0])
    parsed = []
    for item in raw_items:
        try:
            parsed.append(sample_type(item))
        except (ValueError, TypeError):
            parsed.append(item)
    return parsed


def _render_scalar(key: str, val, editable: bool, prefix: str):
    """Render a single scalar value with a type-appropriate widget."""
    widget_key = f"{prefix}_{key}"
    if isinstance(val, bool):
        return st.checkbox(key, value=val, disabled=not editable, key=widget_key)
    elif isinstance(val, int):
        return st.number_input(key, value=val, step=1, disabled=not editable, key=widget_key)
    elif isinstance(val, float):
        return st.number_input(key, value=val, disabled=not editable, key=widget_key)
    else:
        return st.text_input(key, value=str(val), disabled=not editable, key=widget_key)
