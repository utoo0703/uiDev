"""Session state initialization and navigation helper."""

import streamlit as st

from mock_data import build_store


def init_state():
    """Set all session_state defaults. Called once from app.py."""
    if "store" not in st.session_state:
        st.session_state.store = build_store()
    if "screen" not in st.session_state:
        st.session_state.screen = "main"
    if "asset_type" not in st.session_state:
        st.session_state.asset_type = "usecase_schema"
    if "selected_version" not in st.session_state:
        st.session_state.selected_version = None
    if "editor_mode" not in st.session_state:
        st.session_state.editor_mode = None
    if "editor_payload" not in st.session_state:
        st.session_state.editor_payload = None
    if "editor_source_version" not in st.session_state:
        st.session_state.editor_source_version = None


def go(screen: str, **kwargs):
    """Navigate to a screen, optionally setting extra session_state keys."""
    st.session_state.screen = screen
    for k, v in kwargs.items():
        st.session_state[k] = v
