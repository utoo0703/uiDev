# Schemas Directory

Place full JSON schema files here (one per asset type).
The mock_data.py factory loads from these files.
When backend endpoints are ready, this directory and mock_data.py will be retired.
