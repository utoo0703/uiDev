"""API service layer — all backend touchpoints in one place.

Currently uses in-memory session_state store (mock).
When backend is ready, replace each function body with an HTTP call.
Endpoint mapping is documented in each docstring.
"""

import time
import streamlit as st


# ---------------------------------------------------------------------------
# Auth / User context
# ---------------------------------------------------------------------------

def get_current_user() -> dict:
    """Return the logged-in user context from the authenticated session.

    Set by auth.require_auth() at app startup.
    Future: GET /api/v1/auth/me (when backend owns auth fully)
    """
    return st.session_state.get("auth_user", {"email": "unknown", "role": "Viewer"})


# ---------------------------------------------------------------------------
# Read operations
# ---------------------------------------------------------------------------

def fetch_versions(asset_type: str) -> list[dict]:
    """Return version history for an asset type.

    Future: GET /api/v1/schema_versions/{asset_type}
    """
    return st.session_state.store.get(asset_type, [])


def fetch_active_version(asset_type: str) -> dict | None:
    """Return the active version record, or None.

    Future: GET /api/v1/schema_versions/{asset_type}?state=active
    """
    for v in fetch_versions(asset_type):
        if v["is_active"]:
            return v
    return None


def fetch_version_payload(asset_type: str, version: str) -> dict | None:
    """Return a single version record by version tag.

    Future: GET /api/v1/{asset_type}/{version}
    """
    for v in fetch_versions(asset_type):
        if v["version"] == version:
            return v
    return None


def next_version_tag(asset_type: str) -> str:
    """Generate the next version string (e.g. 'v4').

    Future: determined server-side by POST /api/v1/{asset_type}/create_new_version
    """
    nums = [int(v["version"].replace("v", "")) for v in fetch_versions(asset_type)]
    return f"v{max(nums) + 1}" if nums else "v1"


# ---------------------------------------------------------------------------
# Write operations
# ---------------------------------------------------------------------------

def save_draft(asset_type: str, payload: dict, source_version: str | None = None,
               mode: str = "clone") -> str:
    """Save a draft version (new or update).

    Future: POST /api/v1/{asset_type}/{version}/save      (edit)
            POST /api/v1/{asset_type}/create_new_version   (clone)

    Returns the version tag of the saved draft.
    """
    user = get_current_user()
    versions = fetch_versions(asset_type)

    if mode == "clone":
        new_tag = next_version_tag(asset_type)
        versions.append({
            "version": new_tag,
            "state": "draft",
            "is_active": False,
            "uploaded_by": user["email"],
            "last_updated": time.strftime("%Y-%m-%d"),
            "rollback_id": None,
            "payload": payload,
        })
        return new_tag
    else:
        for v in versions:
            if v["version"] == source_version:
                v["payload"] = payload
                v["last_updated"] = time.strftime("%Y-%m-%d")
                break
        return source_version


def submit_version(asset_type: str, payload: dict, source_version: str | None = None,
                   mode: str = "clone") -> str:
    """Promote a version to active, archive the previous active.

    Future: POST /api/v1/{asset_type}/{version}/submit

    Returns the version tag of the newly active version.
    """
    user = get_current_user()
    versions = fetch_versions(asset_type)
    prev_active = fetch_active_version(asset_type)

    if mode == "clone":
        new_tag = next_version_tag(asset_type)
        versions.append({
            "version": new_tag,
            "state": "active",
            "is_active": True,
            "uploaded_by": user["email"],
            "last_updated": time.strftime("%Y-%m-%d"),
            "rollback_id": prev_active["version"] if prev_active else None,
            "payload": payload,
        })
        newly_active = new_tag
    else:
        for v in versions:
            if v["version"] == source_version:
                v["payload"] = payload
                v["state"] = "active"
                v["is_active"] = True
                v["rollback_id"] = prev_active["version"] if prev_active else None
                v["last_updated"] = time.strftime("%Y-%m-%d")
                break
        newly_active = source_version

    # Ensure single active
    for v in versions:
        if v["is_active"] and v["version"] != newly_active:
            v["state"] = "archived"
            v["is_active"] = False

    return newly_active


def promote_draft(asset_type: str, version: str) -> str:
    """Promote an existing draft to active without payload changes (viewer submit).

    Future: POST /api/v1/{asset_type}/{version}/submit

    Returns the version tag of the promoted version.
    """
    record = fetch_version_payload(asset_type, version)
    return submit_version(asset_type, record["payload"], source_version=version, mode="edit")


def rollback(asset_type: str) -> bool:
    """Rollback active to previous active version.

    Future: POST /api/v1/{asset_type}/{active_version}/rollback

    Returns True on success, False if no rollback target.
    """
    active = fetch_active_version(asset_type)
    if not active or not active.get("rollback_id"):
        return False

    target_id = active["rollback_id"]
    for v in fetch_versions(asset_type):
        if v["version"] == target_id:
            v["state"] = "active"
            v["is_active"] = True
            v["rollback_id"] = None
        if v["version"] == active["version"]:
            v["state"] = "archived"
            v["is_active"] = False
    return True
