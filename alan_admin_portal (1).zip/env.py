"""Environment configuration for ALAN ADMIN PORTAL.

Toggle AUTH_MODE between 'mock' (local dev) and 'sso' (real ADA SSO).
All environment variables are read here with sensible defaults.
"""

import os

# ---------------------------------------------------------------------------
# Auth mode: "mock" for local dev, "sso" for real ADA SSO
# ---------------------------------------------------------------------------
AUTH_MODE = os.getenv("AUTH_MODE", "mock")

# ---------------------------------------------------------------------------
# ADA SSO config (used when AUTH_MODE == "sso")
# ---------------------------------------------------------------------------
ADA_LOGIN_PAGE_URL = "ADA_LOGIN_PAGE_URL"
RADAR_DASHBOARD_URL_KEY = "RADAR_DASHBOARD_URL_KEY"


def get_env_var(key: str, default: str = "") -> str:
    """Read an environment variable with a fallback default."""
    return os.getenv(key, default)
