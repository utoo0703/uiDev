"""Editor screen: editable schema form with Save and Submit actions."""

import time

import streamlit as st

from components.schema_form import render_schema_form
from api import save_draft, submit_version
from state import go


def render_editor_screen():
    asset = st.session_state.asset_type
    mode = st.session_state.editor_mode        # "clone" or "edit"
    payload = st.session_state.editor_payload
    source_ver = st.session_state.editor_source_version

    if st.button("Cancel"):
        if mode == "clone":
            go("main")
        else:
            go("viewer", selected_version=source_ver)
        st.rerun()

    label = "Clone from Active" if mode == "clone" else f"Edit Draft {source_ver}"
    st.markdown(f"## Editor  --  {label}")

    # Editable form — collects edited values back
    edited_payload = render_schema_form(payload, editable=True, key_prefix="edit")

    st.divider()

    # ------------------------------------------------------------------
    # Submit dialog
    # ------------------------------------------------------------------
    @st.dialog("Confirm Submit")
    def _submit_dialog():
        st.write(
            "Promote this version to **active**? "
            "The current active version will be archived."
        )
        if st.button("Confirm Submit", key="submit_confirm"):
            new_ver = submit_version(
                asset, edited_payload, source_version=source_ver, mode=mode,
            )
            st.balloons()
            st.success(f"Version {new_ver} promoted to active.")
            time.sleep(1.5)
            go("main", editor_mode=None, editor_payload=None)
            st.rerun()

    # ------------------------------------------------------------------
    # Action buttons
    # ------------------------------------------------------------------
    b1, b2 = st.columns(2)
    with b1:
        if st.button("Save", use_container_width=True):
            saved_ver = save_draft(
                asset, edited_payload, source_version=source_ver, mode=mode,
            )
            st.success(
                f"Saved as new draft {saved_ver}."
                if mode == "clone"
                else f"Draft {saved_ver} updated."
            )
            time.sleep(1.5)
            go("main", editor_mode=None, editor_payload=None)
            st.rerun()
    with b2:
        if st.button("Submit", use_container_width=True):
            _submit_dialog()
