"""Viewer screen: read-only schema display with metadata and download."""

import copy
import json
import time

import streamlit as st

from components.schema_form import render_schema_form
from api import fetch_version_payload, promote_draft
from state import go


def render_viewer_screen():
    asset = st.session_state.asset_type
    ver_id = st.session_state.selected_version

    record = fetch_version_payload(asset, ver_id)
    if not record:
        st.error("Version not found.")
        if st.button("Back to Main"):
            go("main")
            st.rerun()
        st.stop()

    if st.button("Back to Main"):
        go("main")
        st.rerun()

    st.markdown(
        f"## Viewer  --  {asset.replace('_', ' ').title()} / {record['version']}"
    )

    # Metadata card
    st.markdown(
        f'<div class="meta-card">'
        f'<b>Uploaded by:</b> {record["uploaded_by"]} &nbsp;|&nbsp; '
        f'<b>Last Updated:</b> {record["last_updated"]} &nbsp;|&nbsp; '
        f'<b>State:</b> {record["state"]}</div>',
        unsafe_allow_html=True,
    )

    # ------------------------------------------------------------------
    # Action bar — ABOVE the schema so buttons are always visible
    # ------------------------------------------------------------------
    @st.dialog("Confirm Submit")
    def _viewer_submit_dialog():
        st.write(
            f"Promote **{record['version']}** to active? "
            "The current active version will be archived."
        )
        if st.button("Confirm Submit", key="viewer_submit_confirm"):
            promote_draft(asset, record["version"])
            st.balloons()
            st.success("Version promoted to active.")
            time.sleep(1.5)
            go("main")
            st.rerun()

    if record["state"] == "draft":
        c1, c2, c3 = st.columns(3)
        with c1:
            st.download_button(
                "Download Schema (JSON)",
                data=json.dumps(
                    {"version": record["version"], "payload": record["payload"]},
                    indent=2,
                ),
                file_name=f"{asset}_{record['version']}.json",
                mime="application/json",
                use_container_width=True,
            )
        with c2:
            if st.button("Edit Draft", use_container_width=True):
                go(
                    "editor",
                    editor_mode="edit",
                    editor_payload=copy.deepcopy(record["payload"]),
                    editor_source_version=record["version"],
                )
                st.rerun()
        with c3:
            if st.button("Submit", use_container_width=True):
                _viewer_submit_dialog()
    else:
        st.download_button(
            "Download Schema (JSON)",
            data=json.dumps(
                {"version": record["version"], "payload": record["payload"]},
                indent=2,
            ),
            file_name=f"{asset}_{record['version']}.json",
            mime="application/json",
        )

    st.divider()

    # ------------------------------------------------------------------
    # Schema payload — read-only form
    # ------------------------------------------------------------------
    st.markdown("### Schema Payload")
    render_schema_form(record["payload"], editable=False, key_prefix="view")
