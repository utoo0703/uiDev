"""Main screen: active banner, clone, rollback, and version history table."""

import copy
import time

import pandas as pd
import streamlit as st

from api import fetch_active_version, fetch_versions, rollback
from state import go


def render_main_screen():
    asset = st.session_state.asset_type
    st.markdown(f"## {asset.replace('_', ' ').title()}")

    active = fetch_active_version(asset)

    # ------------------------------------------------------------------
    # Active version banner + Clone + Rollback
    # ------------------------------------------------------------------
    if active:
        st.markdown(
            f'<div class="active-banner"><h3>Active Version: {active["version"]}'
            f' &mdash; last updated {active["last_updated"]}</h3></div>',
            unsafe_allow_html=True,
        )

        @st.dialog("Confirm Rollback")
        def _rollback_dialog():
            if not active.get("rollback_id"):
                st.warning("No previous active version to rollback to.")
                return
            st.write(
                f"Rollback active from **{active['version']}** to **{active['rollback_id']}**?"
            )
            if st.button("Confirm Rollback", key="rb_confirm"):
                success = rollback(asset)
                if success:
                    st.success("Rollback successful.")
                else:
                    st.error("Rollback failed.")
                time.sleep(1.5)
                st.rerun()

        c1, c2, c3 = st.columns([1, 1, 4])
        with c1:
            if st.button("Clone Active Schema"):
                go(
                    "editor",
                    editor_mode="clone",
                    editor_payload=copy.deepcopy(active["payload"]),
                    editor_source_version=active["version"],
                )
                st.rerun()
        with c2:
            if st.button("Rollback"):
                _rollback_dialog()

    # ------------------------------------------------------------------
    # Version History Table
    # ------------------------------------------------------------------
    st.markdown("### Version History")
    versions = fetch_versions(asset)
    display = [
        {
            "Version": v["version"],
            "State": v["state"],
            "Active": v["is_active"],
            "Uploaded By": v["uploaded_by"],
            "Last Updated": v["last_updated"],
        }
        for v in versions
    ]
    df = pd.DataFrame(display)
    event = st.dataframe(
        df,
        on_select="rerun",
        selection_mode="single-row",
        use_container_width=True,
        hide_index=True,
    )

    sel_rows = event.selection.rows if event.selection else []
    if sel_rows:
        chosen = versions[sel_rows[0]]
        st.info(f"Selected: **{chosen['version']}** ({chosen['state']})")
        if st.button("View Schema"):
            go("viewer", selected_version=chosen["version"])
            st.rerun()
