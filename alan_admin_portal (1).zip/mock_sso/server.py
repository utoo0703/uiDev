"""Mock ADA SSO server for local development.

Run separately:  python mock_sso/server.py
Listens on port 5001 by default.

This simulates the /idtokeninfo endpoint behavior:
  - No cookie  → 401 with login URL
  - Has cookie → 200 with user claims
"""

import csv
import datetime
import json
import os
from pathlib import Path

import jwt
from flask import Flask, request, redirect, render_template, make_response, jsonify

app = Flask(__name__)
app.secret_key = "development_encoder"

USERS_CSV = Path(__file__).parent / "users.csv"
JWT_SECRET = "mock_sso_secret"
COOKIE_NAME = "alan_sso_token"


def _load_users() -> dict:
    """Load users from CSV. Returns {username: {password, email, role, name}}."""
    users = {}
    if USERS_CSV.exists():
        with open(USERS_CSV) as f:
            for row in csv.DictReader(f):
                users[row["username"]] = row
    return users


def _create_token(user: dict) -> str:
    """Create a JWT token with user claims."""
    payload = {
        "sub": user["username"],
        "email": user["email"],
        "name": user.get("name", user["username"]),
        "role": user.get("role", "Viewer"),
        "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=8),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")


def _decode_token(token: str) -> dict | None:
    """Decode and validate a JWT token."""
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError):
        return None


@app.route("/idtokeninfo", methods=["GET"])
def idtokeninfo():
    """Simulates ADA SSO token check.

    - If valid cookie exists → 200 with user claims
    - Otherwise → 401 with login URL
    """
    token = request.cookies.get(COOKIE_NAME)
    if token:
        claims = _decode_token(token)
        if claims:
            return jsonify(claims), 200

    # Not authenticated — return 401 with login link
    referer = request.headers.get("Referer", "http://localhost:8501")
    login_href = f"http://localhost:5001/login?redirect={referer}"
    return jsonify({
        "_links": {
            "login": {"href": login_href}
        }
    }), 401


@app.route("/login", methods=["GET", "POST"])
def login():
    """Login page — validates credentials and sets JWT cookie."""
    redirect_url = request.args.get("redirect", "http://localhost:8501")

    if request.method == "GET":
        return render_template("login.html", referer=redirect_url, error=None)

    username = request.form.get("username", "")
    password = request.form.get("password", "")
    referer = request.form.get("referer", redirect_url)

    users = _load_users()
    user = users.get(username)

    if not user or user["password"] != password:
        return render_template("login.html", referer=referer, error="Invalid credentials.")

    token = _create_token(user)
    response = make_response(redirect(referer))
    response.set_cookie(COOKIE_NAME, token, httponly=True, max_age=28800)
    return response


@app.route("/logout", methods=["GET"])
def sso_logout():
    """Clear SSO cookie and redirect to login."""
    redirect_url = request.args.get("redirect", "http://localhost:8501")
    response = make_response(redirect(redirect_url))
    response.delete_cookie(COOKIE_NAME)
    return response


if __name__ == "__main__":
    port = int(os.getenv("MOCK_SSO_PORT", 5001))
    print(f"Mock SSO server running on http://localhost:{port}")
    print(f"Users loaded from: {USERS_CSV}")
    app.run(host="0.0.0.0", port=port, debug=True)
