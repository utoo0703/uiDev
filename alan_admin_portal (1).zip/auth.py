"""Authentication layer for ALAN ADMIN PORTAL.

Supports two modes (set via AUTH_MODE env var):
  - "mock"  : Local dev — shows a simple login form inside Streamlit
  - "sso"   : Production — redirects to ADA SSO, reads token from cookie/header

Both modes set st.session_state.auth_user = {"email": ..., "role": ..., "name": ...}
which api.get_current_user() reads.
"""

import logging
import requests
import streamlit as st
from env import AUTH_MODE, get_env_var, ADA_LOGIN_PAGE_URL, RADAR_DASHBOARD_URL_KEY

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Mock users for local dev (replace with CSV/DB as needed)
# ---------------------------------------------------------------------------
MOCK_USERS = {
    "admin": {"password": "admin123", "email": "admin@alan.io", "role": "Super Admin", "name": "Admin User"},
    "editor": {"password": "editor123", "email": "editor@alan.io", "role": "Editor", "name": "Editor User"},
    "viewer": {"password": "viewer123", "email": "viewer@alan.io", "role": "Viewer", "name": "Viewer User"},
}


# ---------------------------------------------------------------------------
# Public API — called from app.py
# ---------------------------------------------------------------------------

def require_auth():
    """Gate the app behind authentication. Blocks rendering until authenticated.

    Call this at the top of app.py, after set_page_config and init_state.
    If the user is not authenticated, this function calls st.stop() so
    nothing below it renders.
    """
    if st.session_state.get("auth_user"):
        return  # already authenticated

    if AUTH_MODE == "mock":
        _mock_login_form()
    else:
        _sso_login()


def logout():
    """Clear auth state and rerun.

    For SSO mode, a full sign-out would also clear the SSO cookie/session.
    """
    for key in list(st.session_state.keys()):
        del st.session_state[key]
    st.rerun()


# ---------------------------------------------------------------------------
# Mock login (local dev)
# ---------------------------------------------------------------------------

def _mock_login_form():
    """Render a simple username/password form for local development."""
    st.markdown("## ALAN ADMIN PORTAL")
    st.markdown("---")
    st.markdown("### Sign In")

    with st.form("login_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("Sign In", use_container_width=True)

    if submitted:
        user = MOCK_USERS.get(username)
        if user and user["password"] == password:
            st.session_state.auth_user = {
                "email": user["email"],
                "role": user["role"],
                "name": user["name"],
            }
            st.rerun()
        else:
            st.error("Invalid username or password.")

    st.caption("Mock credentials: admin / admin123")
    st.stop()


# ---------------------------------------------------------------------------
# Real ADA SSO
# ---------------------------------------------------------------------------

class UnauthorizedError(Exception):
    """Raised when SSO endpoint returns an unexpected status code."""
    def __init__(self, actual_status, message="Expected 401 but got"):
        self.actual_status = actual_status
        self.message = f"{message}: {actual_status}"
        super().__init__(self.message)


def _get_sso_login_url(ada_login_url: str, referrer: str) -> str | None:
    """Check SSO status. Returns login URL if unauthenticated, None if already logged in.

    Future: GET {ada_login_url}/idtokeninfo
    """
    url = ada_login_url + "/idtokeninfo"
    response = requests.get(url=url, headers={"Referer": referrer}, timeout=30)

    if response.status_code == 200:
        return None  # already authenticated

    if response.status_code != 401:
        logger.error(f"Unexpected status code: {response.status_code}")
        raise UnauthorizedError(response.status_code)

    response_data = response.json()
    login_url = response_data.get("_links", {}).get("login", {}).get("href")
    if not login_url:
        logger.error(f"Login URL not found in response: {response_data}")
        raise ValueError("Login URL not found in the response.")

    return login_url


def _append_prefix(url: str) -> str:
    """Ensure URL has the correct http(s) prefix."""
    if "localhost" in url and "http://" not in url:
        return "http://" + url
    elif "localhost" not in url and "https://" not in url:
        return "https://" + url
    return url


def _nav_to(url: str):
    """Redirect the browser using a meta refresh tag."""
    st.write(
        f'<meta http-equiv="refresh" content="0; url=\'{url}\'">',
        unsafe_allow_html=True,
    )


def _sso_login():
    """Attempt ADA SSO authentication. Redirects or blocks until authenticated.

    Flow:
      1. Call /idtokeninfo — if 200, user is authenticated, extract user info.
      2. If 401, get login URL and redirect browser there.
      3. After SSO redirect back, /idtokeninfo returns 200 with user data.
    """
    try:
        ada_url = get_env_var(ADA_LOGIN_PAGE_URL)
        referrer = get_env_var(RADAR_DASHBOARD_URL_KEY)

        if not ada_url:
            st.error("ADA_LOGIN_PAGE_URL is not configured.")
            st.stop()

        sso_url = _get_sso_login_url(ada_login_url=ada_url, referrer=referrer)

        if sso_url is None:
            # Authenticated — fetch user info from the token endpoint
            user_info = _fetch_user_info(ada_url)
            st.session_state.auth_user = user_info
            return

        # Not authenticated — redirect to SSO
        sso_url = _append_prefix(sso_url)
        _nav_to(sso_url)
        st.stop()

    except Exception as e:
        logger.exception(f"ADA SSO error: {e}")
        st.error("ADA SSO Service is currently unavailable.")
        if st.button("Retry SSO Sign In", use_container_width=True):
            st.rerun()
        st.stop()


def _fetch_user_info(ada_login_url: str) -> dict:
    """Extract user details from the SSO token endpoint after successful auth.

    Future: Decode JWT or call /idtokeninfo for user claims.
    Adjust the parsing below to match your actual SSO response shape.
    """
    url = ada_login_url + "/idtokeninfo"
    response = requests.get(url=url, timeout=30)

    if response.status_code == 200:
        data = response.json()
        # Adapt these keys to your actual SSO token claims
        return {
            "email": data.get("email", data.get("sub", "unknown")),
            "role": data.get("role", data.get("groups", ["Viewer"])[0] if data.get("groups") else "Viewer"),
            "name": data.get("name", data.get("preferred_username", "")),
        }

    # Fallback if token info fails
    return {"email": "unknown", "role": "Viewer", "name": "Unknown"}
